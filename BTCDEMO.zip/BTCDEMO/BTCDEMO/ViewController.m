//
//  ViewController.m
//  BTC_demo
//
//  Created by fk on 2018/9/27.
//  Copyright © 2018年 fk. All rights reserved.
//

#import "ViewController.h"
#import <BTCWrapper/BTCWrapper.h>


@interface ViewController ()
{
    IBOutlet UILabel *label1;
    IBOutlet UILabel *label2;

    
    IBOutlet UITextField *textField;
    IBOutlet UILabel *label3;

}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
}


//有兴趣的加微信：ff17067636（每人200元），里面有此静态库源文件

//创建
-(IBAction)createAddress{
    
    [BTCWrapper createAccountWithBlock:^(NSString *private, NSString *address) {
        NSLog(@"%@----%@",private,address);
        self->label1.text = private;
        self->label2.text = address;
    }];
}


//导入
-(IBAction)importPrivate:(id)sender{
    textField.text = label1.text;
    
    [BTCWrapper importPrivateKey:textField.text success:^(NSString *private, NSString *address) {
        NSLog(@"%@----%@",private,address);
        self->label3.text = address;

    } error:^{
        
    }];
}


//https://www.blockchain.com/btc/address/1KFHE7w8BhaENAswwryaoccDb6qcT6DbYY
//查询余额
-(IBAction)getBalance:(id)sender{
    
    [BTCWrapper getBalanceWithAddress:@"1KFHE7w8BhaENAswwryaoccDb6qcT6DbYY" block:^(NSDictionary *dict, BOOL suc) {
        NSLog(@"%@",dict);
    }];
}


//交易记录
-(IBAction)getTx:(id)sender{
    [BTCWrapper getTxlistWithAddress:@"1KFHE7w8BhaENAswwryaoccDb6qcT6DbYY" withPage:1 block:^(NSArray *array, BOOL suc) {
        NSLog(@"%@",array);
    }];
}


//转账
-(IBAction)send:(id)sender{
    [BTCWrapper sendToAddress:@"" money:@"" fromAddress:@"" privateKey:@"" fee:1000 block:^(NSString *hashStr, BOOL suc) {
        
    }];
}


@end
